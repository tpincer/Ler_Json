﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LerJson
{
    class Lista_Usuarios
    {

        public List<Usuario> ListaUsuarios { get; set; }

    }
}
